/**
 * Set up and control an elementary cellular automaton.
 * 
 * @author David J. Barnes and Michael Kölling
 * @version  2016.02.29
 */
public class AutomatonController
{
    // The automaton.
    private Automaton auto;
    
    /**
     * Create an AutomatonController.
     * @param numberOfCells The number of cells in the automaton.
     */
    public AutomatonController(int numberOfCells)
    {
        auto = new Automaton(numberOfCells);
        auto.print();
    }
    
    /**
     * Create an AutomatonController with
     * a default number of cells.
     */
    public AutomatonController()
    {
        this(50);
    }
    
    /**
     * Run the automaton for the given number of steps.
     * @param numSteps The number of steps.
     */
    public void run(int numSteps)
    {
        for(int step = 1; step <= numSteps; step++) {
            step();
        }
    }
    
    /**
     * Run the automaton for a single step.
     */
    public void step()
    {
        auto.update();
        auto.print();
    }
    
    /**
     * Reset the automaton.
     */
    public void reset()
    {
        auto.reset();
        auto.print();
    }
}
/* Part III
 * 25: Yes the same patterns emerge
 * 26: 1 version? Its used to fill the automaton. It also produces a seed of the automaton with a single 'on' cell.
 * 29: If we modify the state, it would lead to incorrect results and change the values needed. 
 * Using nextState ensures that the current state remains unchanged while computing the new state.
 * 30: We could update the last 2 values as we iterate them. The array is better
 * because it minimizes issues of values changing.
 * 33: There should be 256 possibilities.
 * 
 */


